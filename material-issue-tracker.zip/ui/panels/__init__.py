# -*- coding: utf-8 -*-
"""
panels package
Auto-generated at 2025-09-02 16:32:36
"""
