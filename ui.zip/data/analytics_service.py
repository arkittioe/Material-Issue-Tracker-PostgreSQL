# data/analytics_service.py
"""سرویس تحلیل داده‌ها برای داشبورد"""

from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
from sqlalchemy import func, case, and_, desc
from sqlalchemy.orm import Session
import pandas as pd


class AnalyticsService:
    """سرویس جمع‌آوری و تحلیل داده‌ها برای داشبورد"""

    def __init__(self, session_factory):
        self.session_factory = session_factory

    def get_project_statistics(self, project_id: int) -> Dict[str, Any]:
        """آمار کلی پروژه"""
        session = self.session_factory()
        try:
            from models import Project, MTOProgress, MIVRecord, SpoolItem

            # آمار پروژه
            project = session.query(Project).filter(Project.id == project_id).first()
            if not project:
                return {}

            # تعداد خطوط
            total_lines = session.query(
                func.count(func.distinct(MTOProgress.line_no))
            ).filter(
                MTOProgress.project_id == project_id
            ).scalar() or 0

            # پیشرفت کلی پروژه
            overall_progress = session.query(
                func.avg(
                    case(
                        (MTOProgress.total_qty > 0,
                         MTOProgress.used_qty * 100.0 / MTOProgress.total_qty),
                        else_=0
                    )
                )
            ).filter(
                MTOProgress.project_id == project_id
            ).scalar() or 0

            # تعداد MIV های ثبت شده
            total_mivs = session.query(
                func.count(MIVRecord.id)
            ).filter(
                MIVRecord.project_id == project_id
            ).scalar() or 0

            # MIV های امروز
            today_start = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
            today_mivs = session.query(
                func.count(MIVRecord.id)
            ).filter(
                MIVRecord.project_id == project_id,
                MIVRecord.last_updated >= today_start
            ).scalar() or 0

            # خطوط تکمیل شده
            completed_lines = session.query(
                func.count(func.distinct(MTOProgress.line_no))
            ).filter(
                MTOProgress.project_id == project_id,
                MTOProgress.used_qty >= MTOProgress.total_qty
            ).scalar() or 0

            # موجودی اسپول‌ها
            total_spools = session.query(
                func.count(func.distinct(SpoolItem.spool_id))
            ).scalar() or 0

            return {
                'project_name': project.name,
                'overall_progress': round(overall_progress, 1),
                'total_lines': total_lines,
                'completed_lines': completed_lines,
                'total_mivs': total_mivs,
                'today_mivs': today_mivs,
                'total_spools': total_spools
            }

        finally:
            session.close()

    def get_progress_trend(self, project_id: int, days: int = 30) -> List[Dict[str, Any]]:
        """روند پیشرفت پروژه در N روز گذشته"""
        session = self.session_factory()
        try:
            from models import MIVRecord, MTOConsumption

            end_date = datetime.now()
            start_date = end_date - timedelta(days=days)

            # گروه‌بندی MIV ها بر اساس تاریخ
            daily_mivs = session.query(
                func.date(MIVRecord.last_updated).label('date'),
                func.count(MIVRecord.id).label('miv_count')
            ).filter(
                MIVRecord.project_id == project_id,
                MIVRecord.last_updated >= start_date
            ).group_by(
                func.date(MIVRecord.last_updated)
            ).order_by('date').all()

            # تبدیل به فرمت مناسب برای نمودار
            trend_data = []
            for record in daily_mivs:
                trend_data.append({
                    'date': record.date.strftime('%Y-%m-%d') if record.date else '',
                    'miv_count': record.miv_count
                })

            return trend_data

        finally:
            session.close()

    def get_material_consumption_by_type(self, project_id: int) -> List[Dict[str, Any]]:
        """مصرف متریال بر اساس نوع"""
        session = self.session_factory()
        try:
            from models import MTOItem, MTOProgress

            consumption = session.query(
                MTOItem.item_type,
                func.sum(MTOProgress.used_qty).label('total_used'),
                func.sum(MTOProgress.total_qty).label('total_required')
            ).join(
                MTOProgress, MTOItem.id == MTOProgress.mto_item_id
            ).filter(
                MTOProgress.project_id == project_id,
                MTOItem.item_type.isnot(None)
            ).group_by(
                MTOItem.item_type
            ).order_by(
                desc('total_used')
            ).limit(10).all()

            return [
                {
                    'type': record.item_type,
                    'used': round(record.total_used or 0, 2),
                    'required': round(record.total_required or 0, 2),
                    'percentage': round((record.total_used / record.total_required * 100)
                                        if record.total_required else 0, 1)
                }
                for record in consumption
            ]

        finally:
            session.close()

    def get_user_activity_stats(self, days: int = 7) -> List[Dict[str, Any]]:
        """آمار فعالیت کاربران"""
        session = self.session_factory()
        try:
            from models import ActivityLog

            start_date = datetime.now() - timedelta(days=days)

            activities = session.query(
                ActivityLog.user,
                func.count(ActivityLog.id).label('activity_count'),
                func.max(ActivityLog.timestamp).label('last_activity')
            ).filter(
                ActivityLog.timestamp >= start_date
            ).group_by(
                ActivityLog.user
            ).order_by(
                desc('activity_count')
            ).limit(10).all()

            return [
                {
                    'user': record.user,
                    'count': record.activity_count,
                    'last_activity': record.last_activity.strftime('%Y-%m-%d %H:%M')
                    if record.last_activity else ''
                }
                for record in activities
            ]

        finally:
            session.close()
