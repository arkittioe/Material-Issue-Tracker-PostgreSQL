# data/notification_service.py
"""سرویس مدیریت نوتیفیکیشن‌ها و هشدارها"""

from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Callable
from enum import Enum
from dataclasses import dataclass
from PyQt6.QtCore import QObject, pyqtSignal
from sqlalchemy import func, case, and_
from sqlalchemy.orm import Session


class NotificationType(Enum):
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    SUCCESS = "success"


class NotificationPriority(Enum):
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4


@dataclass
class Notification:
    id: str
    title: str
    message: str
    type: NotificationType
    priority: NotificationPriority
    timestamp: datetime
    action: Optional[Callable] = None
    action_text: str = "مشاهده"
    data: Optional[Dict[str, Any]] = None


class NotificationService(QObject):
    """سرویس مدیریت نوتیفیکیشن‌ها"""

    notification_received = pyqtSignal(object)  # Notification object

    def __init__(self, session_factory):
        super().__init__()
        self.session_factory = session_factory
        self.notifications: List[Notification] = []
        self.notification_counter = 0

    def add_notification(self, title: str, message: str,
                         type_: NotificationType = NotificationType.INFO,
                         priority: NotificationPriority = NotificationPriority.MEDIUM,
                         action: Optional[Callable] = None,
                         action_text: str = "مشاهده",
                         data: Optional[Dict[str, Any]] = None):
        """اضافه کردن نوتیفیکیشن جدید"""
        self.notification_counter += 1
        notification = Notification(
            id=f"notif_{self.notification_counter}",
            title=title,
            message=message,
            type=type_,
            priority=priority,
            timestamp=datetime.now(),
            action=action,
            action_text=action_text,
            data=data
        )

        self.notifications.append(notification)
        self.notification_received.emit(notification)

    def check_low_stock_spools(self, threshold: int = 10):
        """بررسی موجودی کم اسپول‌ها"""
        session = self.session_factory()
        try:
            from models import SpoolItem

            low_stock_items = session.query(
                SpoolItem.component_type,
                func.sum(SpoolItem.qty_available).label('total_available')
            ).group_by(
                SpoolItem.component_type
            ).having(
                func.sum(SpoolItem.qty_available) < threshold
            ).all()

            for item in low_stock_items:
                self.add_notification(
                    f"⚠️ موجودی کم: {item.component_type}",
                    f"موجودی فعلی: {item.total_available} عدد",
                    NotificationType.WARNING,
                    NotificationPriority.HIGH
                )

        finally:
            session.close()

    def check_incomplete_lines(self, project_id: int):
        """بررسی خطوط ناتمام"""
        session = self.session_factory()
        try:
            from models import MTOProgress

            # خطوطی که بیش از 80% پیشرفت دارند اما کامل نشده‌اند
            incomplete_lines = session.query(
                MTOProgress.line_no,
                func.avg(
                    case(
                        (MTOProgress.total_qty > 0,
                         MTOProgress.used_qty * 100.0 / MTOProgress.total_qty),
                        else_=0
                    )
                ).label('progress')
            ).filter(
                MTOProgress.project_id == project_id
            ).group_by(
                MTOProgress.line_no
            ).having(
                and_(
                    func.avg(
                        case(
                            (MTOProgress.total_qty > 0,
                             MTOProgress.used_qty * 100.0 / MTOProgress.total_qty),
                            else_=0
                        )
                    ) > 80,
                    func.avg(
                        case(
                            (MTOProgress.total_qty > 0,
                             MTOProgress.used_qty * 100.0 / MTOProgress.total_qty),
                            else_=0
                        )
                    ) < 100
                )
            ).all()

            for line in incomplete_lines:
                self.add_notification(
                    f"📋 خط ناتمام: {line.line_no}",
                    f"پیشرفت: {line.progress:.1f}%",
                    NotificationType.INFO,
                    NotificationPriority.MEDIUM
                )

        finally:
            session.close()

    def check_overdue_mivs(self, days: int = 7):
        """بررسی MIV های معوق"""
        session = self.session_factory()
        try:
            from models import MIVRecord

            cutoff_date = datetime.now() - timedelta(days=days)

            old_incomplete_mivs = session.query(
                MIVRecord
            ).filter(
                MIVRecord.is_complete == False,
                MIVRecord.last_updated < cutoff_date
            ).limit(10).all()

            for miv in old_incomplete_mivs:
                days_old = (datetime.now() - miv.last_updated).days
                self.add_notification(
                    f"⏰ MIV معوق: {miv.miv_tag}",
                    f"خط {miv.line_no} - {days_old} روز از آخرین بروزرسانی",
                    NotificationType.WARNING,
                    NotificationPriority.MEDIUM
                )

        finally:
            session.close()
