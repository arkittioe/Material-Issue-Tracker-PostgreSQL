# ui/widgets/__init__.py
from .splash_screen import SplashScreen
from .notification_widget import (
    NotificationWidget,
    NotificationPanel,
    NotificationManager,
    setup_notification_system
)

__all__ = [
    'SplashScreen',
    'NotificationWidget',
    'NotificationPanel',
    'NotificationManager',
    'setup_notification_system'
]
