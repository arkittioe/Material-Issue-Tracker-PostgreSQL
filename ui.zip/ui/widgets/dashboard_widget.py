# ui/widgets/dashboard_widget.py
"""ویجت اصلی داشبورد"""

from PyQt6.QtCore import *
from PyQt6.QtWidgets import *
from PyQt6.QtGui import *
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.font_manager as fm
import numpy as np

# تنظیم فونت فارسی
plt.rcParams['font.family'] = ['Tahoma', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False


class StatCard(QFrame):
    """کارت نمایش آمار"""

    def __init__(self, title: str, value: str, icon: str = "📊",
                 color: str = "#3498db", parent=None):
        super().__init__(parent)
        self.setup_ui(title, value, icon, color)

    def setup_ui(self, title, value, icon, color):
        self.setStyleSheet(f"""
            QFrame {{
                background-color: white;
                border: 2px solid {color};
                border-radius: 10px;
                padding: 15px;
            }}
        """)

        layout = QVBoxLayout()

        # Header
        header_layout = QHBoxLayout()
        icon_label = QLabel(icon)
        icon_label.setStyleSheet("font-size: 24px;")
        header_layout.addWidget(icon_label)
        header_layout.addStretch()
        layout.addLayout(header_layout)

        # Value
        self.value_label = QLabel(value)
        self.value_label.setStyleSheet(f"""
            font-size: 32px;
            font-weight: bold;
            color: {color};
        """)
        layout.addWidget(self.value_label)

        # Title
        title_label = QLabel(title)
        title_label.setStyleSheet("font-size: 14px; color: #7f8c8d;")
        layout.addWidget(title_label)

        self.setLayout(layout)

    def update_value(self, new_value: str):
        """بروزرسانی مقدار"""
        self.value_label.setText(new_value)


class ChartWidget(FigureCanvas):
    """ویجت نمودار"""

    def __init__(self, parent=None):
        self.figure = Figure(figsize=(5, 4), dpi=100)
        super().__init__(self.figure)
        self.setParent(parent)

    def plot_line_chart(self, data: List[Dict], x_field: str, y_field: str, title: str):
        """رسم نمودار خطی"""
        self.figure.clear()
        ax = self.figure.add_subplot(111)

        x_values = [item[x_field] for item in data]
        y_values = [item[y_field] for item in data]

        ax.plot(x_values, y_values, marker='o', linestyle='-', linewidth=2, markersize=6)
        ax.set_title(title, fontsize=14, pad=20)
        ax.set_xlabel(x_field, fontsize=12)
        ax.set_ylabel(y_field, fontsize=12)
        ax.grid(True, alpha=0.3)

        # Rotate x labels if needed
        if len(x_values) > 10:
            plt.setp(ax.xaxis.get_majorticklabels(), rotation=45, ha='right')

        self.figure.tight_layout()
        self.draw()

    def plot_bar_chart(self, data: List[Dict], x_field: str, y_field: str, title: str):
        """رسم نمودار میله‌ای"""
        self.figure.clear()
        ax = self.figure.add_subplot(111)

        x_values = [item[x_field] for item in data]
        y_values = [item[y_field] for item in data]

        colors = plt.cm.Blues(np.linspace(0.4, 0.8, len(x_values)))
        bars = ax.bar(x_values, y_values, color=colors)

        # Add value labels on bars
        for bar in bars:
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width() / 2., height,
                    f'{height:.1f}',
                    ha='center', va='bottom', fontsize=10)

        ax.set_title(title, fontsize=14, pad=20)
        ax.set_xlabel(x_field, fontsize=12)
        ax.set_ylabel(y_field, fontsize=12)
        ax.grid(True, axis='y', alpha=0.3)

        # Rotate x labels
        plt.setp(ax.xaxis.get_majorticklabels(), rotation=45, ha='right')

        self.figure.tight_layout()
        self.draw()

    def plot_pie_chart(self, data: List[Dict], label_field: str, value_field: str, title: str):
        """رسم نمودار دایره‌ای"""
        self.figure.clear()
        ax = self.figure.add_subplot(111)

        labels = [item[label_field] for item in data[:5]]  # Top 5
        values = [item[value_field] for item in data[:5]]

        # Add "Others" if more than 5 items
        if len(data) > 5:
            others_value = sum(item[value_field] for item in data[5:])
            labels.append("سایر")
            values.append(others_value)

        colors = plt.cm.Set3(range(len(labels)))
        wedges, texts, autotexts = ax.pie(values, labels=labels, colors=colors,
                                          autopct='%1.1f%%', startangle=90)

        ax.set_title(title, fontsize=14, pad=20)

        # Make percentage text bold
        for autotext in autotexts:
            autotext.set_fontweight('bold')
            autotext.set_fontsize(10)

        self.figure.tight_layout()
        self.draw()


class DashboardWidget(QWidget):
    """ویجت اصلی داشبورد"""

    def __init__(self, analytics_service, project_id: int, parent=None):
        super().__init__(parent)
        self.analytics_service = analytics_service
        self.project_id = project_id
        self.stat_cards = {}
        self.charts = {}
        self.setup_ui()
        self.load_data()

        # تایمر برای بروزرسانی خودکار
        self.update_timer = QTimer()
        self.update_timer.timeout.connect(self.load_data)
        self.update_timer.start(60000)  # هر 60 ثانیه

    def setup_ui(self):
        main_layout = QVBoxLayout()

        # Header
        header_layout = QHBoxLayout()
        title_label = QLabel("<h2>📊 داشبورد مدیریتی</h2>")
        header_layout.addWidget(title_label)
        header_layout.addStretch()

        refresh_btn = QPushButton("🔄 بروزرسانی")
        refresh_btn.clicked.connect(self.load_data)
        header_layout.addWidget(refresh_btn)

        main_layout.addLayout(header_layout)

        # آمار کلی - بخش بالا
        stats_layout = QHBoxLayout()

        self.stat_cards['progress'] = StatCard(
            "پیشرفت کلی", "0%", "📈", "#2ecc71"
        )
        stats_layout.addWidget(self.stat_cards['progress'])

        self.stat_cards['lines'] = StatCard(
            "تعداد خطوط", "0", "📋", "#3498db"
        )
        stats_layout.addWidget(self.stat_cards['lines'])

        self.stat_cards['mivs'] = StatCard(
            "MIV های امروز", "0", "📄", "#e74c3c"
        )
        stats_layout.addWidget(self.stat_cards['mivs'])

        self.stat_cards['spools'] = StatCard(
            "اسپول‌های فعال", "0", "🔧", "#f39c12"
        )
        stats_layout.addWidget(self.stat_cards['spools'])

        main_layout.addLayout(stats_layout)

        # نمودارها - بخش پایین
        charts_layout = QGridLayout()

        # نمودار روند پیشرفت
        trend_group = QGroupBox("روند پیشرفت پروژه")
        trend_layout = QVBoxLayout()
        self.charts['trend'] = ChartWidget()
        trend_layout.addWidget(self.charts['trend'])
        trend_group.setLayout(trend_layout)
        charts_layout.addWidget(trend_group, 0, 0)

        # نمودار مصرف متریال
        material_group = QGroupBox("مصرف متریال بر اساس نوع")
        material_layout = QVBoxLayout()
        self.charts['material'] = ChartWidget()
        material_layout.addWidget(self.charts['material'])
        material_group.setLayout(material_layout)
        charts_layout.addWidget(material_group, 0, 1)

        # نمودار فعالیت کاربران
        activity_group = QGroupBox("فعالیت کاربران (7 روز اخیر)")
        activity_layout = QVBoxLayout()
        self.charts['activity'] = ChartWidget()
        activity_layout.addWidget(self.charts['activity'])
        activity_group.setLayout(activity_layout)
        charts_layout.addWidget(activity_group, 1, 0, 1, 2)

        main_layout.addLayout(charts_layout)
        self.setLayout(main_layout)

    def load_data(self):
        """بارگذاری داده‌ها از سرویس"""
        try:
            # آمار کلی
            stats = self.analytics_service.get_project_statistics(self.project_id)
            if stats:
                self.stat_cards['progress'].update_value(f"{stats['overall_progress']:.1f}%")
                self.stat_cards['lines'].update_value(f"{stats['total_lines']}/{stats['completed_lines']}")
                self.stat_cards['mivs'].update_value(str(stats['today_mivs']))
                self.stat_cards['spools'].update_value(str(stats['total_spools']))

            # روند پیشرفت
            trend_data = self.analytics_service.get_progress_trend(self.project_id, 30)
            if trend_data:
                self.charts['trend'].plot_line_chart(
                    trend_data, 'date', 'miv_count', 'تعداد MIV در 30 روز گذشته'
                )

            # مصرف متریال
            material_data = self.analytics_service.get_material_consumption_by_type(self.project_id)
            if material_data:
                self.charts['material'].plot_pie_chart(
                    material_data, 'type', 'used', 'توزیع مصرف متریال'
                )

            # فعالیت کاربران
            activity_data = self.analytics_service.get_user_activity_stats(7)
            if activity_data:
                self.charts['activity'].plot_bar_chart(
                    activity_data, 'user', 'count', 'فعالیت کاربران'
                )

        except Exception as e:
            QMessageBox.warning(self, "خطا", f"خطا در بارگذاری داده‌ها: {str(e)}")
