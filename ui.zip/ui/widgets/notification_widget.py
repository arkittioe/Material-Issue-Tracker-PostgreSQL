# ui/widgets/notification_widget.py
"""ویجت‌های ساده و کارآمد برای نمایش نوتیفیکیشن"""

from PyQt6.QtCore import *
from PyQt6.QtWidgets import *
from PyQt6.QtGui import *
from datetime import datetime
from enum import Enum


class NotificationType(Enum):
    """انواع نوتیفیکیشن"""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    SUCCESS = "success"


class NotificationPriority(Enum):
    """اولویت نوتیفیکیشن"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class Notification:
    """مدل ساده نوتیفیکیشن"""

    def __init__(self, title, message, type_=NotificationType.INFO, priority=NotificationPriority.MEDIUM):
        self.title = title
        self.message = message
        self.type = type_
        self.priority = priority
        self.timestamp = datetime.now()
        self.id = id(self)


class NotificationWidget(QFrame):
    """ویجت نمایش یک نوتیفیکیشن"""
    closed = pyqtSignal(object)

    def __init__(self, notification, parent=None):
        super().__init__(parent)
        self.notification = notification
        self.setup_ui()

    def setup_ui(self):
        """راه‌اندازی رابط کاربری"""
        self.setFrameStyle(QFrame.Shape.Box)
        self.setMaximumHeight(100)

        # رنگ‌بندی ساده
        colors = {
            NotificationType.INFO: "#3498db",
            NotificationType.WARNING: "#f39c12",
            NotificationType.ERROR: "#e74c3c",
            NotificationType.SUCCESS: "#27ae60"
        }

        color = colors.get(self.notification.type, "#95a5a6")

        self.setStyleSheet(f"""
            QFrame {{
                background-color: white;
                border: 2px solid {color};
                border-radius: 5px;
                padding: 5px;
                margin: 2px;
            }}
        """)

        # چیدمان اصلی
        layout = QHBoxLayout()
        layout.setSpacing(10)

        # آیکون ساده
        icon_map = {
            NotificationType.INFO: "ℹ️",
            NotificationType.WARNING: "⚠️",
            NotificationType.ERROR: "❌",
            NotificationType.SUCCESS: "✅"
        }

        icon_label = QLabel(icon_map.get(self.notification.type, "📢"))
        icon_label.setStyleSheet("font-size: 20px;")
        layout.addWidget(icon_label)

        # محتوا
        content_layout = QVBoxLayout()

        # عنوان
        title_label = QLabel(self.notification.title)
        title_label.setStyleSheet(f"font-weight: bold; color: {color};")
        title_label.setWordWrap(True)
        content_layout.addWidget(title_label)

        # پیام
        message_label = QLabel(self.notification.message)
        message_label.setWordWrap(True)
        message_label.setStyleSheet("color: #555; font-size: 12px;")
        content_layout.addWidget(message_label)

        # زمان
        time_label = QLabel(self.notification.timestamp.strftime("%H:%M"))
        time_label.setStyleSheet("color: #999; font-size: 10px;")
        content_layout.addWidget(time_label)

        layout.addLayout(content_layout, 1)

        # دکمه بستن
        close_btn = QPushButton("×")
        close_btn.setFixedSize(20, 20)
        close_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                border: none;
                font-size: 16px;
                color: #999;
            }
            QPushButton:hover {
                color: #e74c3c;
            }
        """)
        close_btn.clicked.connect(lambda: self.closed.emit(self))
        layout.addWidget(close_btn)

        self.setLayout(layout)


class NotificationPanel(QDockWidget):
    """پنل ساده نمایش نوتیفیکیشن‌ها"""

    def __init__(self, parent=None):
        super().__init__("اعلان‌ها", parent)
        self.notifications = []
        self.setup_ui()

    def setup_ui(self):
        """راه‌اندازی رابط کاربری"""
        # ویجت اصلی
        main_widget = QWidget()
        layout = QVBoxLayout()

        # هدر ساده
        header_layout = QHBoxLayout()

        title_label = QLabel("🔔 اعلان‌ها")
        title_label.setStyleSheet("font-size: 14px; font-weight: bold;")
        header_layout.addWidget(title_label)

        header_layout.addStretch()

        # دکمه پاک کردن
        clear_btn = QPushButton("پاک کردن همه")
        clear_btn.clicked.connect(self.clear_all)
        header_layout.addWidget(clear_btn)

        layout.addLayout(header_layout)

        # خط جداکننده
        line = QFrame()
        line.setFrameStyle(QFrame.Shape.HLine)
        layout.addWidget(line)

        # ناحیه اسکرول
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        self.container = QWidget()
        self.notifications_layout = QVBoxLayout(self.container)
        self.notifications_layout.addStretch()

        scroll.setWidget(self.container)
        layout.addWidget(scroll)

        main_widget.setLayout(layout)
        self.setWidget(main_widget)

        # تنظیمات dock
        self.setFeatures(QDockWidget.DockWidgetFeature.DockWidgetMovable |
                         QDockWidget.DockWidgetFeature.DockWidgetClosable)
        self.setMinimumWidth(300)

    def add_notification(self, notification):
        """اضافه کردن نوتیفیکیشن جدید"""
        widget = NotificationWidget(notification)
        widget.closed.connect(self.remove_notification)

        # اضافه کردن به ابتدای لیست
        self.notifications_layout.insertWidget(0, widget)
        self.notifications.append(widget)

    def remove_notification(self, widget):
        """حذف نوتیفیکیشن"""
        if widget in self.notifications:
            self.notifications.remove(widget)
            widget.deleteLater()

    def clear_all(self):
        """پاک کردن همه نوتیفیکیشن‌ها"""
        reply = QMessageBox.question(
            self,
            "تایید",
            "همه اعلان‌ها حذف شوند؟",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            for widget in self.notifications[:]:
                widget.deleteLater()
            self.notifications.clear()


class NotificationManager:
    """مدیر ساده نوتیفیکیشن‌ها"""

    def __init__(self, main_window):
        self.main_window = main_window
        self.panel = None

    def setup(self):
        """راه‌اندازی سیستم نوتیفیکیشن"""
        # ایجاد پنل
        self.panel = NotificationPanel(self.main_window)
        self.main_window.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.panel)
        self.panel.hide()

        # اضافه کردن به منو
        if hasattr(self.main_window, 'menuBar'):
            view_menu = None
            # پیدا کردن منوی View یا ایجاد آن
            for action in self.main_window.menuBar().actions():
                if action.text() == "&View":
                    view_menu = action.menu()
                    break

            if not view_menu:
                view_menu = self.main_window.menuBar().addMenu("&View")

            # اضافه کردن action
            notification_action = QAction("🔔 نمایش اعلان‌ها", self.main_window)
            notification_action.setCheckable(True)
            notification_action.triggered.connect(self.toggle_panel)
            view_menu.addAction(notification_action)

    def toggle_panel(self, checked):
        """نمایش/مخفی کردن پنل"""
        if self.panel:
            self.panel.setVisible(checked)

    def show_notification(self, title, message, type_=NotificationType.INFO, priority=NotificationPriority.MEDIUM):
        """نمایش نوتیفیکیشن جدید"""
        if not self.panel:
            return

        notification = Notification(title, message, type_, priority)
        self.panel.add_notification(notification)

        # اگر پنل مخفی است و نوتیفیکیشن مهم است، نمایش بده
        if not self.panel.isVisible() and priority == NotificationPriority.HIGH:
            self.panel.show()

    def show_info(self, title, message):
        """نمایش نوتیفیکیشن اطلاعاتی"""
        self.show_notification(title, message, NotificationType.INFO)

    def show_warning(self, title, message):
        """نمایش نوتیفیکیشن هشدار"""
        self.show_notification(title, message, NotificationType.WARNING, NotificationPriority.HIGH)

    def show_error(self, title, message):
        """نمایش نوتیفیکیشن خطا"""
        self.show_notification(title, message, NotificationType.ERROR, NotificationPriority.HIGH)

    def show_success(self, title, message):
        """نمایش نوتیفیکیشن موفقیت"""
        self.show_notification(title, message, NotificationType.SUCCESS)


# تابع کمکی برای یکپارچه‌سازی با MainWindow
def setup_notification_system(main_window):
    """راه‌اندازی آسان سیستم نوتیفیکیشن"""
    manager = NotificationManager(main_window)
    manager.setup()
    return manager


# مثال استفاده
if __name__ == "__main__":
    import sys

    app = QApplication(sys.argv)

    # پنجره تست
    window = QMainWindow()
    window.setWindowTitle("تست نوتیفیکیشن")
    window.setGeometry(100, 100, 800, 600)

    # راه‌اندازی سیستم نوتیفیکیشن
    notif_manager = setup_notification_system(window)

    # ویجت تست برای ارسال نوتیفیکیشن
    central_widget = QWidget()
    layout = QVBoxLayout()

    # دکمه‌های تست
    btn_info = QPushButton("ارسال اطلاعات")
    btn_info.clicked.connect(lambda: notif_manager.show_info("اطلاعات", "این یک پیام اطلاعاتی است"))

    btn_warning = QPushButton("ارسال هشدار")
    btn_warning.clicked.connect(lambda: notif_manager.show_warning("هشدار", "موجودی اسپول کم است!"))

    btn_error = QPushButton("ارسال خطا")
    btn_error.clicked.connect(lambda: notif_manager.show_error("خطا", "خطا در اتصال به دیتابیس"))

    btn_success = QPushButton("ارسال موفقیت")
    btn_success.clicked.connect(lambda: notif_manager.show_success("موفقیت", "عملیات با موفقیت انجام شد"))

    layout.addWidget(btn_info)
    layout.addWidget(btn_warning)
    layout.addWidget(btn_error)
    layout.addWidget(btn_success)
    layout.addStretch()

    central_widget.setLayout(layout)
    window.setCentralWidget(central_widget)

    window.show()
    sys.exit(app.exec())
